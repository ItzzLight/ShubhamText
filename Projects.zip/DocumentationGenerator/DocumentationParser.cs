using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

public class FieldDoc
{
    public string Name = "";    ///// Manually Initialized for Removing Warnings
    public string Type = "";    ///// Manually Initialized for Removing Warnings
    public string Default = ""; ///// Manually Initialized for Removing Warnings
    public bool Required;
    public string Description = ""; ///// Manually Initialized for Removing Warnings
    public string Modifiers = "";   ///// Manually Initialized for Removing Warnings
}

public class MethodDoc
{
    public string Name = "";    ///// Manually Initialized for Removing Warnings
    public string Description = ""; ///// Manually Initialized for Removing Warnings
    public List<ParamDoc> Parameters = new List<ParamDoc>();
    public string ReturnType = "";  ///// Manually Initialized for Removing Warnings
    public string Modifiers = "";   ///// Manually Initialized for Removing Warnings
}

public class ParamDoc
{
    public string Name = "";    ///// Manually Initialized for Removing Warnings
    public string Type = "";    ///// Manually Initialized for Removing Warnings
    public string Default = ""; ///// Manually Initialized for Removing Warnings
    public bool Required;
    public string Description = ""; ///// Manually Initialized for Removing Warnings
}

public class ClassDoc
{
    public string ClassName = "";   ///// Manually Initialized for Removing Warnings
    public string Summary = "";     ///// Manually Initialized for Removing Warnings
    public List<FieldDoc> Fields = new List<FieldDoc>();
    public List<MethodDoc> Methods = new List<MethodDoc>();
}

public static class DocumentationParser
{
    public static ClassDoc? Parse(string filePath)
    {
        if (!File.Exists(filePath)) return null;
        var code = File.ReadAllText(filePath);
        var tree = CSharpSyntaxTree.ParseText(code);
        var root = tree.GetCompilationUnitRoot();

        var classNode = root.DescendantNodes().OfType<ClassDeclarationSyntax>().FirstOrDefault();
        if (classNode == null) return null;

        var doc = new ClassDoc
        {
            ClassName = classNode.Identifier.Text,
            Summary = GetXmlSummary(classNode)
        };

        // Fields
        foreach (var field in classNode.DescendantNodes().OfType<FieldDeclarationSyntax>())
        {
            foreach (var variable in field.Declaration.Variables)
            {
                doc.Fields.Add(new FieldDoc
                {
                    Name = variable.Identifier.Text,
                    Type = field.Declaration.Type.ToString(),
                    Default = variable.Initializer?.Value.ToString() ?? "None",
                    Required = field.Modifiers.Any(m => m.Text == "public"),
                    Description = GetXmlSummary(field),
                    Modifiers = string.Join(" ", field.Modifiers.Select(m => m.Text))
                });
            }
        }

        // Methods
        foreach (var method in classNode.DescendantNodes().OfType<MethodDeclarationSyntax>())
        {
            var m = new MethodDoc
            {
                Name = method.Identifier.Text,
                Description = GetXmlSummary(method),
                ReturnType = method.ReturnType.ToString(),
                Modifiers = string.Join(" ", method.Modifiers.Select(mod => mod.Text))
            };
            foreach (var param in method.ParameterList.Parameters)
            {
                m.Parameters.Add(new ParamDoc
                {
                    Name = param.Identifier.Text,
                    Type = param.Type?.ToString() ?? "",
                    Default = param.Default?.Value.ToString() ?? "",
                    Required = param.Default == null,
                    Description = "" // You can extract XML param comments here if present
                });
            }
            doc.Methods.Add(m);
        }

        return doc;
    }

    private static string GetXmlSummary(SyntaxNode node)
    {
        var trivia = node.GetLeadingTrivia()
            .Select(i => i.GetStructure())
            .OfType<DocumentationCommentTriviaSyntax>()
            .FirstOrDefault();
        if (trivia == null) return "";
        var summary = trivia.Content.OfType<XmlElementSyntax>()
            .FirstOrDefault(e => e.StartTag.Name.LocalName.Text == "summary");
        return summary?.Content.ToString().Trim() ?? "";
    }
}