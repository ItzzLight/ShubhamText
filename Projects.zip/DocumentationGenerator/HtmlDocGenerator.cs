using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

public static class HtmlDocGenerator
{
    // Merge manual descriptions from existing HTML if update is set
    public static void MergeManualDescriptions(ClassDoc doc, string htmlPath)
    {
        string html = File.ReadAllText(htmlPath);

        // Merge field descriptions
        foreach (var field in doc.Fields)
        {
            var match = Regex.Match(html, $@"<span class=""field-name""[^>]*>{Regex.Escape(field.Name)}</span>.*?<div class=""dropdown-content"">\s*<b>Description:</b>\s*(.*?)<br>", RegexOptions.Singleline);
            if (match.Success && !string.IsNullOrWhiteSpace(match.Groups[1].Value) && !match.Groups[1].Value.Contains("No description"))
                field.Description = match.Groups[1].Value.Trim();
        }
        // Merge method descriptions
        foreach (var method in doc.Methods)
        {
            var match = Regex.Match(html, $@"<span class=""method-name""[^>]*>{Regex.Escape(method.Name)}</span>.*?<div class=""dropdown-content"">\s*<b>Description:</b>\s*(.*?)<br>", RegexOptions.Singleline);
            if (match.Success && !string.IsNullOrWhiteSpace(match.Groups[1].Value) && !match.Groups[1].Value.Contains("No description"))
                method.Description = match.Groups[1].Value.Trim();
        }
        // Merge summary
        var summaryMatch = Regex.Match(html, @"<div class=""doc-section"">\s*<p>(.*?)</p>", RegexOptions.Singleline);
        if (summaryMatch.Success && !string.IsNullOrWhiteSpace(summaryMatch.Groups[1].Value) && !summaryMatch.Groups[1].Value.Contains("No summary"))
            doc.Summary = summaryMatch.Groups[1].Value.Trim();
    }

    public static void GenerateHtml(
        ClassDoc doc,
        string outputPath,
        string scriptPath,
        string iconPath,
        string sourceCode,
        bool addCode = true)
    {
        var html = new StringBuilder();

        html.AppendLine("<!DOCTYPE html>");
        html.AppendLine("<html lang=\"en\">");
        html.AppendLine("<head>");
        html.AppendLine("    <meta charset=\"UTF-8\">");
        html.AppendLine($"    <title>{doc.ClassName}.cs Mechanics & Documentation</title>");
        html.AppendLine($"    <link rel=\"icon\" type=\"image/png\" href=\"{iconPath}\">");
        html.AppendLine($"<link rel=\"stylesheet\" href=\"{Data.GetStylesheetPath()}\">");
        html.AppendLine("    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/github-dark.min.css\">");
        html.AppendLine("</head>");
        html.AppendLine("<body>");
        html.AppendLine("  <header>");
        html.AppendLine("      <div class=\"header-main\">");
        html.AppendLine($"        <img class=\"header-icon\" src=\"{iconPath}\" alt=\"Icon\">");
        html.AppendLine($"        <div class=\"header-title-group\">");
        html.AppendLine($"          <h1 class=\"project-title\">{Data.projectName} : Source Documentation</h1>");
        html.AppendLine($"          <div class=\"header-script-label\">Unity C# Script: <code>{doc.ClassName}.cs</code></div>");
        html.AppendLine("        </div>");
        html.AppendLine("      </div>");
        html.AppendLine("      <div class=\"header-socials\">");
        foreach (var kvp in Data.SocialLinks)
        {
            string site = kvp.Key;
            string profile = kvp.Value[0];
            string icon = kvp.Value[1];
            html.AppendLine($"        <a class=\"header-btn\" href=\"{profile}\" target=\"_blank\" title=\"{site}\"><img src=\"{icon}\" alt=\"{site}\"><span class=\"header-btn-text\">{site}</span></a>");
        }
        html.AppendLine("      </div>");
        html.AppendLine("    </header>");
        html.AppendLine("    <div class=\"main-body-card\">");
        html.AppendLine("      <div class=\"container\">");

        // Mechanics Overview Section (placeholder, you can parse from comments or add manually)
        html.AppendLine("        <h2 class=\"overview-title section-slide-header\">Mechanics Overview</h2>");
        html.AppendLine("        <ul class=\"mechanics\">");
        html.AppendLine("            <li><span class=\"mechanic-title\">[Add Mechanic Title]</span><div class=\"explanation\">[Add mechanic summary here]</div></li>");
        html.AppendLine("        </ul>");

        // Script Documentation & Explanations
        html.AppendLine("        <h2 class=\"overview-title section-slide-header\">Script Documentation & Explanations</h2>");
        html.AppendLine("        <div class=\"doc-section doc-section-hover\">");
        html.AppendLine($"<div class=\"overview-summary\">{(string.IsNullOrWhiteSpace(doc.Summary) ? "[Add summary/documentation here]" : doc.Summary)}</div>");
        html.AppendLine("            <div class=\"animated-fadein-text\" style=\"margin-top:16px; color:#b5eaff;\">[You can manually add more documentation here if needed]</div>");
        html.AppendLine("        </div>");

        // Fields & Properties
        html.AppendLine("        <h2 class=\"section-slide-header\">Fields & Properties</h2>");
        html.AppendLine("        <ul class=\"field-list\">");
        foreach (var f in doc.Fields)
        {
            html.AppendLine("            <li class=\"field-item\">");
            html.AppendLine($"                <span class=\"field-name\" data-hover=\"{(string.IsNullOrWhiteSpace(f.Description) ? "[Add description here]" : f.Description)}\">{f.Modifiers} {f.Type} <b>{f.Name}</b></span>");
            html.AppendLine($"                <span class=\"field-default\">[Default: <code>{(string.IsNullOrWhiteSpace(f.Default) ? "[Add default]" : f.Default)}</code>]</span>");
            if (f.Required) html.AppendLine("                <span class=\"required\">Required</span>");
            html.AppendLine("                <div class=\"dropdown-content\">");
            html.AppendLine($"                    <b>Description:</b> {(string.IsNullOrWhiteSpace(f.Description) ? "[Add description here]" : f.Description)}<br>");
            html.AppendLine($"                    <b>Type:</b> <code>{(string.IsNullOrWhiteSpace(f.Type) ? "[Add type]" : f.Type)}</code>");
            html.AppendLine($"                    <b>Modifiers:</b> <code>{f.Modifiers}</code>");
            html.AppendLine("                </div>");
            html.AppendLine("            </li>");
        }
        html.AppendLine("        </ul>");

        // Methods
        html.AppendLine("        <h2 class=\"section-slide-header\">Methods</h2>");
        html.AppendLine("        <ul class=\"method-list\">");
        foreach (var m in doc.Methods)
        {
            html.AppendLine("            <li class=\"method-item\">");
            html.AppendLine($"                <span class=\"method-name\" data-hover=\"{(string.IsNullOrWhiteSpace(m.Description) ? "[Add description here]" : m.Description)}\">{m.Modifiers} {m.ReturnType} <b>{m.Name}</b>({string.Join(", ", m.Parameters.Select(p => $"{p.Type} {p.Name}"))})</span>");
            html.AppendLine("                <div class=\"dropdown-content\">");
            html.AppendLine($"                    <b>Description:</b> {(string.IsNullOrWhiteSpace(m.Description) ? "[Add description here]" : m.Description)}<br>");
            html.AppendLine("                    <b>Parameters:</b>");
            html.AppendLine("                    <ul class=\"param-list\">");
            if (m.Parameters.Count > 0)
            {
                foreach (var p in m.Parameters)
                {
                    html.AppendLine($"                        <li class=\"param-item\"><b>{p.Name}</b> <code>{p.Type}</code>{(p.Required ? " <span class='required'>Required</span>" : "")}{(!string.IsNullOrWhiteSpace(p.Default) ? $" [Default: <code>{p.Default}</code>]" : "")} - {(string.IsNullOrWhiteSpace(p.Description) ? "[Add parameter description]" : p.Description)}</li>");
                }
            }
            else
            {
                html.AppendLine("                        <li class=\"param-item\"><i>None</i></li>");
            }
            html.AppendLine("                    </ul>");
            html.AppendLine($"                    <b>Return Type:</b> <code>{m.ReturnType}</code>");
            html.AppendLine($"                    <b>Modifiers:</b> <code>{m.Modifiers}</code>");
            html.AppendLine("                </div>");
            html.AppendLine("            </li>");
        }
        html.AppendLine("        </ul>");

        // Source Code Section
        if (addCode)
        {
            html.AppendLine("        <h2 class=\"overview-title section-slide-header\">Source Code</h2>");
            html.AppendLine("        <div class=\"doc-section doc-section-hover\">");
            html.AppendLine("          <div class=\"overview-summary source-summary-hover\">");
            html.AppendLine("            <button class=\"source-toggle styled-source-toggle\" onclick=\"this.nextElementSibling.classList.toggle('open')\">Show/Hide Source Code</button>");
            html.AppendLine("            <div class=\"source-content\">");
            var lines = sourceCode.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n').ToList();

            html.AppendLine("                <div class=\"source-code-wrapper\">");
            html.Append("                  <pre class=\"source-pre\"><code class=\"language-csharp\">");
            for (int i = 0; i < lines.Count; i++)
            {
                string lineClass = "";
                if (Data.SourceLineSeparator == Data.LineSeparator.Highlight)
                    lineClass = (i % 2 == 0) ? " code-line-even" : " code-line-odd";
                html.AppendLine($"<span class=\"code-line{lineClass}\">{System.Net.WebUtility.HtmlEncode(lines[i])}</span>");
            }
            html.AppendLine("                  </code></pre>");

            if (Data.ShowLineNumbers)
            {
                html.AppendLine("                  <div class=\"line-numbers\">");
                for (int i = 1; i <= lines.Count; i++)
                {
                    html.AppendLine($"<span>{i}</span>");
                }
                html.AppendLine("                  </div>");
            }

            if (Data.SourceLineSeparator == Data.LineSeparator.Split)
            {
                html.AppendLine("                  <div class=\"line-splitters\">");
                for (int i = 1; i < lines.Count; i++)
                {
                    // 1.6em is the line height, 18px is the top padding of .source-pre code
                    html.AppendLine($"<div class=\"line-split\" style=\"top:calc({i} * 1.6em + 18px);\"></div>");
                }
                html.AppendLine("                  </div>");
            }

            html.AppendLine("                </div>");
            html.AppendLine("            </div>");
            html.AppendLine("          </div>");
            html.AppendLine("          <div class=\"animated-fadein-text scroll-fade-note\" style=\"margin-top:16px; color:#b5eaff;\">[You can add extra notes or manual documentation here]</div>");
            html.AppendLine("        </div>");
        }

        html.AppendLine("        <div class=\"animated-fadein-text scroll-fade-note\" style=\"margin-top:32px; color:#b5eaff;\">[You can add extra notes or manual documentation here]</div>");
        html.AppendLine("    </div>");
        html.AppendLine("    <div id=\"hover-tooltip\" class=\"hover-def\"></div>");
        html.AppendLine($"    <script src=\"{scriptPath}\"></script>");
        html.AppendLine("    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js\"></script>");
        html.AppendLine("    <script>hljs.highlightAll();</script>");
        html.AppendLine("</body>");
        html.AppendLine("</html>");

        File.WriteAllText(outputPath, html.ToString());
        Console.WriteLine("HTML documentation generated: " + outputPath);
    }
}