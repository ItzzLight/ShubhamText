﻿// filepath: DocumentationGenerator/Program.cs
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        //_generate();
        Generate(args);
    }

    public static void _generate()
    {
        BatchGenerateDocsFromBaseToDocsFolder();
    }

    public static void Generate(string[] args)
    {
        if (args.Length == 0)
        {
            StartDocumentationProcess(Data.ResolvedDefaultSourceFilePath);
        }
        else if (Directory.Exists(args[0]))
        {
            BatchGenerateDocs(args[0], Data.ResolvedStylesheetPath, Data.ResolvedScriptPath, Data.UpdateExisting, Data.DeleteUnavailableFiles);
        }
        else if (args.Length > 1 && args[0] == "--batch")
        {
            string sourceFolder = args[1];
            string outputRoot = args.Length > 2 ? args[2] : Data.ResolvedAbsoluteOutputHtmlDir;
            Program.BatchGenerateDocs(
                folderPath: sourceFolder,
                stylesheetPath: Data.ResolvedStylesheetPath,
                scriptPath: Data.ResolvedScriptPath,
                updateExisting: Data.UpdateExisting,
                deleteUnavailableFiles: Data.DeleteUnavailableFiles,
                outputRoot: outputRoot
            );
            return;
        }
        else
        {
            StartDocumentationProcess(args[0]);
        }
    }

    /// <summary>
    /// Generates documentation for a single file. Params override Data.cs if provided.
    /// </summary>
    public static void StartDocumentationProcess(
        string? csFile = null,
        string? stylesheetPath = null,
        string? scriptPath = null,
        bool? updateExisting = null,
        string? outputHtmlPath = null)
    {
        csFile ??= Data.ResolvedDefaultSourceFilePath;
        stylesheetPath ??= Data.ResolvedStylesheetPath;
        scriptPath ??= Data.ResolvedScriptPath;
        bool update = updateExisting ?? Data.UpdateExisting;

        string resolvedCsFile = csFile;

        string outputPath;
        if (Data.AutoGenerateFilePath)
        {
            string dir = Path.GetDirectoryName(resolvedCsFile) ?? "";
            outputPath = Path.Combine(dir, Path.GetFileNameWithoutExtension(resolvedCsFile) + ".html");
        }
        else if (Data.SendToDocsFolder)
        {
            // Mirror the folder structure inside DocsFolder
            string relative = Path.GetRelativePath(Data.basePath, resolvedCsFile);
            string docsFolder = Data.ResolvedDocsFolder;
            string htmlPath = Path.Combine(docsFolder, Path.ChangeExtension(relative, ".html"));
            string? htmlDir = Path.GetDirectoryName(htmlPath);
            htmlDir ??= docsFolder;
            Directory.CreateDirectory(htmlDir);
            outputPath = htmlPath;
        }
        else if (!string.IsNullOrEmpty(outputHtmlPath))
        {
            if (Directory.Exists(outputHtmlPath) || outputHtmlPath == Data.ResolvedAbsoluteOutputHtmlDir)
            {
                string dir = outputHtmlPath == Data.ResolvedAbsoluteOutputHtmlDir
                    ? Data.ResolvedAbsoluteOutputHtmlDir
                    : outputHtmlPath;
                outputPath = Path.Combine(dir, Path.GetFileNameWithoutExtension(resolvedCsFile) + ".html");
            }
            else
            {
                outputPath = outputHtmlPath;
            }
        }
        else
        {
            // Fallback: same folder as source
            string dir = Path.GetDirectoryName(resolvedCsFile) ?? "";
            outputPath = Path.Combine(dir, Path.GetFileNameWithoutExtension(resolvedCsFile) + ".html");
        }

        DocumentationGenerator.Generate(
            resolvedCsFile,
            outputPath,
            stylesheetPath,
            scriptPath,
            update
        );
    }

    /// <summary>
    /// Batch generates documentation for all .cs files in a folder (recursively).
    /// </summary>
    public static void BatchGenerateDocs(
        string folderPath,
        string? stylesheetPath = null,
        string? scriptPath = null,
        bool? updateExisting = null,
        bool? deleteUnavailableFiles = null,
        string? outputRoot = null)
    {
        stylesheetPath ??= Data.ResolvedStylesheetPath;
        scriptPath ??= Data.ResolvedScriptPath;
        bool update = updateExisting ?? Data.UpdateExisting;
        bool deleteMissing = deleteUnavailableFiles ?? Data.DeleteUnavailableFiles;
        outputRoot ??= Data.ResolvedAbsoluteOutputHtmlDir;

        string resolvedFolderPath = Data.ResolvePath(folderPath);
        string resolvedOutputRoot = outputRoot;

        // Find all .cs files recursively
        var csFiles = Directory.GetFiles(resolvedFolderPath, "*.cs", SearchOption.AllDirectories);

        // Track generated HTML files for cleanup
        var generatedHtmlFiles = new HashSet<string>();

        foreach (var csFile in csFiles)
        {
            // Output path mirrors folder hierarchy, but with .html extension
            string relative = Path.GetRelativePath(resolvedFolderPath, csFile);
            string htmlPath = Path.Combine(resolvedOutputRoot, Path.ChangeExtension(relative, ".html"));
            string? htmlDir = Path.GetDirectoryName(htmlPath);
            htmlDir ??= resolvedOutputRoot;
            Directory.CreateDirectory(htmlDir);

            DocumentationGenerator.Generate(
                csFile,
                htmlPath,
                Data.ResolvePath(stylesheetPath),
                Data.ResolvePath(scriptPath),
                update
            );
            generatedHtmlFiles.Add(Path.GetFullPath(htmlPath));
        }

        // Optionally delete HTML files for missing source files
        if (deleteMissing)
        {
            var allHtml = Directory.GetFiles(resolvedOutputRoot, "*.html", SearchOption.AllDirectories);
            foreach (var html in allHtml)
            {
                if (!generatedHtmlFiles.Contains(Path.GetFullPath(html)))
                {
                    File.Delete(html);
                    Console.WriteLine($"Deleted orphaned doc: {html}");
                }
            }
        }
    }

    public static void BatchGenerateDocsFromBaseToDocsFolder()
    {
        string sourceFolder = Data.basePath;
        string docsFolder = Data.ResolvedDocsFolder;

        var csFiles = Directory.GetFiles(sourceFolder, "*.cs", SearchOption.AllDirectories);

        foreach (var csFile in csFiles)
        {
            // Mirror folder structure inside DocsFolder
            string relative = Path.GetRelativePath(sourceFolder, csFile);
            string htmlPath = Path.Combine(docsFolder, Path.ChangeExtension(relative, ".html"));
            string? htmlDir = Path.GetDirectoryName(htmlPath);
            htmlDir ??= docsFolder;
            Directory.CreateDirectory(htmlDir);

            DocumentationGenerator.Generate(
                csFile,
                htmlPath,
                Data.ResolvedStylesheetPath,
                Data.ResolvedScriptPath,
                Data.UpdateExisting
            );
        }
        Console.WriteLine("Batch documentation generation complete.");
    }
}