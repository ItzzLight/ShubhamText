using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Pickable.cs
/// <summary>
/// Handles the picking up, dropping, throwing, and placing of items in the game.
/// </summary>
/// <remarks>
/// This class manages the logic for picking up items, creating visual copies for holding and placement previews,
/// and handling interactions such as throwing and placing items.<br/>
/// It also includes settings for placement and throwing behavior.<br/>
/// The item can be picked up when detected, and it provides functionality for dropping, throwing,
/// and placing the item in the game world.<br/>
/// It uses Unity's MonoBehaviour for lifecycle management and implements IDetectionHandler for detection events.
/// </remarks>
/// <seealso cref="ObjectDetection"/>
/// <seealso cref="IDetectionHandler"/>
/// <seealso cref="PickableSupporter"/>
/// <author>ItzzLight</author>
[AddComponentMenu("Itzz Light/Objects/General/Pickable")]
[DisallowMultipleComponent]
[RequireComponent(typeof(ObjectDetection))]
public class Pickable : MonoBehaviour, IDetectionHandler
{

    [Space][Header("Base Settings")][Space]
    /// <!-- Base Settings -->


    /// <summary>Reference to the holder GameObject for picked items.</summary>
    [Tooltip("Reference to the holder GameObject for picked items.")]
    [SerializeField] GameObject holder;

    /// <summary>If true, copies all children recursively when creating visual copies.</summary>
    [Tooltip("If true, copies all children recursively when creating visual copies.")]
    [SerializeField] bool copyRecursively = true;

    /// <summary>Cooldown time (in seconds) before the item can be picked up again after being dropped.</summary>
    [Tooltip("Cooldown time (in seconds) before the item can be picked up again after being dropped.")]
    public float pickUpCooldown = 0.5f;



    /// <!-- Behaviour Settings -->

    [Space, MarkedHeader("#d400ff#Behaviour Settings#")]
    public PlacementSettings placementSettings = Defaults.DefaultPlacementSettings;
    public ThrowSettings throwSettings = Defaults.DefaultThrowSettings;
    public BounceSettings bounceSettings = Defaults.DefaultBounceSettings;



    /// <!-- Public State Variables -->

    /// <summary>True if the item can currently be picked up.</summary>
    [HideInInspector] public bool AllowPicking = true;

    /// <summary>True if the item is currently being held.</summary>
    public bool isHolding { get; private set; } = false;


    /// <!-- Private State Variables -->

    private ObjectDetection objectDetection;
    private Rigidbody _rigidbody;
    private GameObject visualCopy;
    private GameObject placementPreview;
    private GameObject middleHolder;
    private bool canPickUp = false;
    private bool isPlacing = false;
    private bool placeCancelled = false;
    private bool throwCancelled = false;
    private bool isChargingThrow = false;
    private bool initialRigidbody = true;
    private float throwCharge = 0f;
    private float throwStartTime = 0f;
    private float placementRotationY = 0f; // Add this field to accumulate rotation
    private readonly float middleHolderScalingConstant = Defaults.DefaultMiddleHolderScalingConstant; // Constant for middle holder scaling
    private Vector3 middleHolderInitScale; // Stores the initial scale of the middle holder
    private Quaternion placementBaseRotation = Quaternion.identity; // Stores the base rotation for placement


    /// <!-- Caching the KeyCodes for Faster Access -->
    private KeyCode pickKey = KeyBinds.GetKey(KeyAction.PickUp);
    private KeyCode dropKey = KeyBinds.GetKey(KeyAction.Drop);
    private KeyCode throwKey = KeyBinds.GetKey(KeyAction.Throw);
    private KeyCode placeKey = KeyBinds.GetKey(KeyAction.Place);
    private KeyCode cancelKey = KeyBinds.GetKey(KeyAction.Cancel);
    private KeyCode rotateCWKey = KeyBinds.GetKey(KeyAction.RotatePlacementCW);
    private KeyCode rotateCCWKey = KeyBinds.GetKey(KeyAction.RotatePlacementCCW);


    private void Start()
    {
        objectDetection = gameObject.GetComponent<ObjectDetection>();
        setRigidBody();

        if (placementSettings.placementDistance == 0) placementSettings.placementDistance = objectDetection.detectionDistance;

        // Debug.Log($"Holder = {holder}");
        if (holder == null) holder = SceneScript.obj.pObjs.itemHolders[0];
        if (holder == null)
        { Debug.LogError("Holder not set for Pickable object: " + gameObject.name); }

        middleHolder ??= SceneScript.obj.pObjs.itemHolders[2];
        middleHolderInitScale = middleHolder.transform.localScale;

        placementSettings.previewMaterial ??= SceneScript.obj.pObjs.materials.placementPreviewMaterial;
        KeyBinds.OnKeyBindChanged += OnKeyBindChanged;

        if (bounceSettings.addBouncePhysics) _addBouncePhysics();
    }

    private void OnKeyBindChanged(KeyAction action, KeyCode key)
    {
        // Update cached keys if relevant
        if (action == KeyAction.PickUp) pickKey = key;
        else if (action == KeyAction.Drop) dropKey = key;
        else if (action == KeyAction.Throw) throwKey = key;
        else if (action == KeyAction.Place) placeKey = key;
        else if (action == KeyAction.Cancel) cancelKey = key;
        else if (action == KeyAction.RotatePlacementCW) rotateCWKey = key;
        else if (action == KeyAction.RotatePlacementCCW) rotateCCWKey = key;
    }

    private void setRigidBody()
    {
        if (!gameObject.TryGetComponent(out _rigidbody))
        {
            _rigidbody = gameObject.AddComponent<Rigidbody>();

            _rigidbody.useGravity = true;
            _rigidbody.isKinematic = false;
            _rigidbody.collisionDetectionMode = CollisionDetectionMode.Continuous;
            _rigidbody.linearVelocity = Vector3.zero;
            _rigidbody.angularVelocity = Vector3.zero;
            _rigidbody.mass = throwSettings.mass;

            initialRigidbody = false;
            // The following is to prevent the "unused" warning.
            initialRigidbody = initialRigidbody ? true : false;
        }
    }

    /// <summary>Called when detection ends for this object.</summary>
    public void DetectionEnd()
    {
        canPickUp = false;
    }

    /// <summary>Called when detection starts for this object.</summary>
    public void DetectionStart()
    {
        canPickUp = true;
    }

    /// <summary>Called every frame while detected. Handles pickup input.</summary>
    public void DetectionUpdate()
    {
        if (canPickUp && AllowPicking && Input.GetKey(pickKey))
        {
            // Drop logic
            if (holder.transform.childCount == 1)
            {
                _toDrop(holder.transform.GetChild(0).gameObject);
            }
            else if (holder.transform.childCount > 1)
            {
                List<GameObject> children = holder.GetChildren();
                for (int i = 0, len = children.Count; i < len; i++)
                    _toDrop(children[i]);
            }
            StartCoroutine(PickUp());
        }
    }

    /// <summary>
    /// Helper Function to Help Dropping an Already Existing Item.
    /// </summary>
    /// <param name="toDrop">The GameObject(visualCopy) to Drop.</param>
    /// <remarks>
    /// Takes in the GameObject for the visualCopy, accesses the associated
    /// `PickableSupporter.supportedObject` to access the Base object.<br/>
    /// Then Drops and Resets the base `Pickable` object.
    /// </remarks>
    private void _toDrop(GameObject toDrop)
    {
        Pickable temp = toDrop.transform.GetComponent<PickableSupporter>().supportedObject;
        if (temp)
        {
            temp.Drop();
            temp.Reset();
        }
    }

    /// <summary>Assign this in Awake or Start</summary>
    private void _addBouncePhysics()
    {
        Collider[] colliders = GetComponents<Collider>();
        PhysicsMaterial bounceMat = new PhysicsMaterial("BallBounce")
        {
            bounciness = bounceSettings.bounciness,
            bounceCombine = bounceSettings.bounceCombine,
            frictionCombine = bounceSettings.frictionCombine,
            dynamicFriction = bounceSettings.dynamicFriction,
            staticFriction = bounceSettings.staticFriction
        };
        for (int i = 0; i < colliders.Length; i++)
            colliders[i].material = bounceMat;
    }

    /// <summary>
    /// Handles all per-frame logic while the item is held (drop, throw, place).
    /// </summary>
    public void SupportedUpdate()
    {
        if (!isHolding) return;

        // Drop if Throwing is not allowed
        if (throwSettings.disableThrow)
        {
            if (Input.GetKeyDown(dropKey)) Drop();
            return;
        }   /// <!-- Conflicts with disable Placement (TOFIX) -->

        // Drop logic
        if (dropKey != throwKey)
        {
            if (Input.GetKeyDown(dropKey))
            {
                Drop();
                return;
            }
        }

        // Throw logic (shared for both cases)
        if (!isChargingThrow && Input.GetKeyDown(throwKey))
        {
            StartThrowCharge();
            return;
        }
        else if (isChargingThrow)
        {
            UpdateThrowCharge();

            if (Input.GetKey(cancelKey)) CancelThrow();
            else if (Input.GetKeyUp(throwKey))
            {
                if (Time.time - throwStartTime < throwSettings.dropThreshold)
                {
                    CancelThrow();
                    if (dropKey == throwKey) Drop(); // Only drop if keys are the same
                }
                else if (!throwCancelled) Throw();
                else throwCancelled = false;
            }
            return;
        }

        // Placement logic
        if (placementSettings.disablePlacement) return;
        if (!isPlacing && !placeCancelled && Input.GetKeyDown(placeKey)) StartPlacementPreview();
        else if (isPlacing && Input.GetKeyUp(placeKey)) ConfirmPlacement();
        else if (isPlacing && Input.GetKey(cancelKey)) CancelPlacement();

        if (!Input.GetKey(placeKey)) placeCancelled = false;

        if (isPlacing) UpdatePlacementPreview();
    }

    /// <summary>
    /// Coroutine for picking up the item. Creates a visual copy and disables the original.
    /// </summary>
    /// <returns>IEnumerator for Unity coroutine.</returns>
    private IEnumerator PickUp()
    {
        canPickUp = false;
        objectDetection.AllowDetection = false;
        objectDetection.EndDetection(objectDetection.coroutineEndHandlers);
        isHolding = true;
        if (_rigidbody != null) _rigidbody.isKinematic = true;

        yield return null;
        visualCopy = CreateVisualCopy(gameObject, copyRecursively);
        visualCopy.transform.SetParent(holder.transform, false);
        visualCopy.AddComponent<PickableSupporter>().supportedObject = this;

        ScaleToFit.ScaleAndPositionObject(visualCopy, holder);

        yield return new WaitUntil(() => objectDetection.notSettingHandlers);
        visualCopy.SetActive(true);
        gameObject.SetActive(false);
        objectDetection.AllowDetection = true;
    }

    /// <summary>
    /// Drops the item, restoring its original state.
    /// </summary>
    private void Drop()
    {
        if (visualCopy == null)
        {
            Debug.LogError($"No VisualCopy set for {name} : Nothing to Drop.");
            return;
        }
        ScaleToFit.ScaleAndPositionObject(visualCopy, middleHolder);
        gameObject.transform.CopyLocalTransform(visualCopy.transform, copyScale: false);
        DestroyCopy();

        objectDetection.AllowDetection = false;
        gameObject.SetActive(true);
        isHolding = false;
        StartCoroutine(inPickUpCooldown());
        
        if (_rigidbody != null) _rigidbody.isKinematic = false;
    }

    private IEnumerator inPickUpCooldown()
    {
        yield return new WaitForSeconds(pickUpCooldown);
        objectDetection.AllowDetection = true;
    }

    private void Reset()
    {
        DestroyCopy(1);
        isHolding = false;
        isPlacing = false;
        placeCancelled = false;
        throwCancelled = false;
        isChargingThrow = false;
        throwCharge = 0f;
        throwStartTime = 0f;
        placementRotationY = 0f;
        placementBaseRotation = Quaternion.identity;
        if (_rigidbody != null)
        {
            _rigidbody.isKinematic = false;
            _rigidbody.linearVelocity = Vector3.zero;
            _rigidbody.angularVelocity = Vector3.zero;
        }
    }

    /// <summary>
    /// Destroys the visual copy or placement preview.
    /// </summary>
    /// <param name="flag">0 for visual copy, 1 for placement preview.</param>
    private void DestroyCopy(int flag = 0)
    {
        if (flag == 0)
        {
            if (visualCopy == null) return;
            visualCopy.SetActive(false);
            Destroy(visualCopy);
            visualCopy = null;
        }
        else
        {
            if (placementPreview == null) return;
            placementPreview.SetActive(false);
            Destroy(placementPreview);
            placementPreview = null;
        }
    }

    /// <summary>
    /// Creates a visual-only copy of the item for holding or preview.
    /// </summary>
    /// <param name="original">Original GameObject.</param>
    /// <param name="copyRecursively">Whether to copy children recursively.</param>
    /// <param name="parent">Parent transform for the copy.</param>
    /// <param name="name">Name for the copy.</param>
    /// <param name="disableFlags">Flags to disable features.</param>
    /// <returns>The visual copy GameObject.</returns>
    /// <remarks>
    /// This method creates a visual copy of the original GameObject, allowing for modifications without affecting the original.
    /// </remarks>
    private GameObject CreateVisualCopy(GameObject original, bool copyRecursively = false, Transform parent = null, string name = null, string[] disableFlags = null)
    {
        GameObject copy = _createVisualCopy(original, copyRecursively, (disableFlags == null) ? null : new HashSet<string>(disableFlags));
        name ??= original.name + "_visualCopy";
        copy.name = name;
        copy.SetActive(false);
        if (parent) copy.transform.SetParent(parent);
        return copy;
    }

    /// <summary>
    /// Internal method for creating a visual copy with feature flags.
    /// </summary>
    /// <param name="original">Original GameObject.</param>
    /// <param name="copyRecursively">Whether to copy children recursively.</param>
    /// <param name="disableFlags">Feature flags.</param>
    /// <returns>The visual copy GameObject.</returns>
    private GameObject _createVisualCopy(GameObject original, bool copyRecursively = false, HashSet<string> disableFlags = null)
    {
        bool copyPSflag = true, copyLightFlag = true;
        if (disableFlags != null)
        {
            copyPSflag = !disableFlags.Contains("PS");
            copyLightFlag = !disableFlags.Contains("Light");
        }

        GameObject copy = new GameObject(original.name);

        // Copy transform
        copy.transform.CopyLocalTransform(original.transform);

        // Copy MeshFilter
        MeshFilter origMF = original.GetComponent<MeshFilter>();
        if (origMF)
        {
            MeshFilter copyMF = copy.AddComponent<MeshFilter>();
            copyMF.sharedMesh = origMF.sharedMesh;
        }

        // Copy MeshRenderer
        MeshRenderer origMR = original.GetComponent<MeshRenderer>();
        if (origMR)
        {
            MeshRenderer copyMR = copy.AddComponent<MeshRenderer>();
            copyMR.sharedMaterials = origMR.sharedMaterials;
            copyMR.enabled = origMR.enabled;
        }


        // Copy Particle Simulation
        ParticleSystem origPS;
        if (copyPSflag && (origPS = original.GetComponent<ParticleSystem>()))
        {
            ParticleSystem copyPS = Instantiate(origPS, copy.transform);
            copyPS.transform.localPosition = Vector3.zero;
        }

        // Copy Lights
        Light origLight;
        if (copyLightFlag && (origLight = original.GetComponent<Light>()))
        {/* 
            Light copyLight = Instantiate(origLight, copy.transform);
            copyLight.transform.localPosition = Vector3.zero; */

            Light copyLight = copy.AddComponent<Light>();
            copyLight.CopyValues(origLight);
            copyLight.shadowResolution = UnityEngine.Rendering.LightShadowResolution.Low;
        }

        // Recursively copy children if requested
        if (copyRecursively)
        {
            foreach (Transform child in original.transform)
            {
                GameObject childCopy = _createVisualCopy(child.gameObject, true, disableFlags);
                childCopy.transform.SetParent(copy.transform);
            }
        }

        return copy;
    }

    /// <summary>
    /// Starts the placement preview for the item.
    /// </summary>
    private void StartPlacementPreview()
    {
        isPlacing = true;
        placementPreview = CreateVisualCopy(gameObject, copyRecursively, parent: transform.parent, name: name + "_placementPreview", disableFlags: placementSettings.disableCopyFlags);
        placementPreview.transform.CopyLocalTransform(transform);

        // Get the object's vertical axis from bounds
        Vector3 objectUp = ScaleToFit.GetVerticalAxisFromBounds(placementPreview);

        // Set initial rotation
        if (placementSettings.retainPlacementRotation)
        {
            // Default: align to surface normal
            Vector3 up = Raycasting.hit.normal;
            Vector3 forward = Vector3.ProjectOnPlane(Vector3.forward, up).normalized;
            if (forward.sqrMagnitude < 0.01f)
                forward = Vector3.ProjectOnPlane(Vector3.right, up).normalized;
            placementPreview.transform.rotation = Quaternion.LookRotation(forward, up);
        }
        else
        {
            // Face the camera, but ensure upright (up = object's vertical axis)
            Vector3 toCamera = (Camera.main.transform.position - Raycasting.hit.point).normalized;
            Vector3 forward = Vector3.ProjectOnPlane(-toCamera, objectUp).normalized;
            if (forward.sqrMagnitude < 0.01f)
                forward = Vector3.ProjectOnPlane(Camera.main.transform.up, objectUp).normalized;
            placementBaseRotation = Quaternion.LookRotation(forward, objectUp);
            placementPreview.transform.rotation = placementBaseRotation;
        }

        ApplyPreviewMaterial(placementPreview, placementSettings.useGeneratedInstead ? null : placementSettings.previewMaterial);
        UpdatePlacementPreview();
    }

    /// <summary>
    /// Updates the placement preview position and visibility.
    /// </summary>
    private void UpdatePlacementPreview()
    {
        // Preventing Separate Raycasting for now, to improve performance.
        if (Raycasting.hit.distance < placementSettings.placementDistance)
        {
            // Check if surface is "horizontal enough"
            float angle = Vector3.Angle(Raycasting.hit.normal, Vector3.up);
            if (angle > placementSettings.placementLeniency)
            {
                placementPreview.SetActive(false);
                return;
            }

            placementPreview.SetActive(true);

            float rotationDelta = 0f;
            if (Input.GetKey(rotateCWKey))
                rotationDelta -= placementSettings.placementRotationSpeed * Time.deltaTime;
            if (Input.GetKey(rotateCCWKey))
                rotationDelta += placementSettings.placementRotationSpeed * Time.deltaTime;

            placementRotationY += rotationDelta;

            // Always use the object's vertical axis from bounds
            Vector3 objectUp = ScaleToFit.GetGlobalVerticalAxisFromBounds(placementPreview);

            Quaternion baseRotation;
            if (placementSettings.retainPlacementRotation)
            {
                Vector3 forward = Vector3.ProjectOnPlane(Vector3.forward, objectUp).normalized;
                if (forward.sqrMagnitude < 0.01f)
                    forward = Vector3.ProjectOnPlane(Vector3.right, objectUp).normalized;
                baseRotation = Quaternion.LookRotation(forward, objectUp);
            }
            else
            {
                Vector3 toCamera = (Camera.main.transform.position - Raycasting.hit.point).normalized;
                Vector3 forward = Vector3.ProjectOnPlane(-toCamera, objectUp).normalized;
                if (forward.sqrMagnitude < 0.01f)
                    forward = Vector3.ProjectOnPlane(Camera.main.transform.up, objectUp).normalized;
                baseRotation = Quaternion.LookRotation(forward, objectUp);
            }

            placementPreview.transform.rotation = baseRotation * Quaternion.AngleAxis(placementRotationY, objectUp);

            Vector3 boundsCenter = ScaleToFit.GetBounds(placementPreview).center;
            Vector3 pivotOffset = placementPreview.transform.position - boundsCenter;
            placementPreview.transform.position = Raycasting.hit.point + pivotOffset + ScaleToFit.GetBottomOffset(placementPreview);
        }
        else
        {
            placementPreview.SetActive(false);
        }
    }

    /// <summary>
    /// Confirms the placement of the item.
    /// </summary>
    private void ConfirmPlacement()
    {
        if (placementPreview == null || !placementPreview.activeSelf)
        { CancelPlacement(); return; }

        isPlacing = false;

        gameObject.transform.CopyLocalTransform(placementPreview.transform, false);

        DestroyCopy(1);
        DestroyCopy();
        gameObject.SetActive(true);
        if (_rigidbody != null) _rigidbody.isKinematic = false;
        isHolding = false;
    }

    /// <summary>
    /// Cancels the placement preview.
    /// </summary>
    private void CancelPlacement()
    {
        isPlacing = false;
        placeCancelled = true;
        DestroyCopy(1);
    }

    /// <summary>
    /// Applies a preview material to the placement preview object.
    /// </summary>
    /// <param name="preview">Preview GameObject.</param>
    /// <param name="mat">Material to apply.</param>
    private void ApplyPreviewMaterial(GameObject preview, Material mat = null)
    {
        if (mat)
        {
            MeshRenderer rend = preview.GetComponent<MeshRenderer>();
            if (rend)
            {
                rend.material = mat;
                return;
            }

            foreach (var renderer in preview.GetComponentsInChildren<MeshRenderer>())
            {
                renderer.materials = new Material[] { mat };
            }
            return;
        }
        Shader urpLit = Shader.Find("Universal Render Pipeline/Lit");
        foreach (var renderer in preview.GetComponentsInChildren<MeshRenderer>())
        {
            foreach (var _mat in renderer.materials)
            {
                _mat.shader = urpLit;
                _mat.color = new Color(0.5f, 0.5f, 0.5f, 0.5f);
                _mat.SetFloat("_Surface", 1f); // 1 = Transparent
                _mat.SetFloat("_Blend", 0f);   // Alpha blending
                _mat.SetFloat("_SrcBlend", (float)UnityEngine.Rendering.BlendMode.SrcAlpha);
                _mat.SetFloat("_DstBlend", (float)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
                _mat.SetFloat("_ZWrite", 0f);
                _mat.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
                _mat.renderQueue = 3000;
            }
        }
    }

    /// <summary>
    /// Starts charging for a throw.
    /// </summary>
    private void StartThrowCharge()
    {
        isChargingThrow = true;
        throwStartTime = Time.time;
        throwCharge = 0f;
        throwCancelled = false;
        ScaleToFit.ScaleAndPositionObject(visualCopy, middleHolder);
    }

    /// <summary>
    /// Updates the throw charge based on elapsed time.
    /// </summary>
    private void UpdateThrowCharge()
    {
        float elapsed = Time.time - throwStartTime;
        throwCharge = Mathf.Clamp01(elapsed / throwSettings.maxThrowChargeTime);

        middleHolder.transform.localScale = middleHolderInitScale * (0.7f + throwCharge * middleHolderScalingConstant);

        // Auto-cancel if held too long
        if (elapsed > throwSettings.maxThrowHoldTime)
        {
            CancelThrow();
        }
    }

    /// <summary>
    /// Cancels the current throw charge.
    /// </summary>
    private void CancelThrow()
    {
        isChargingThrow = false;
        throwCancelled = true;
        throwCharge = 0f;

        middleHolder.transform.localScale = middleHolderInitScale;
        ScaleToFit.ScaleAndPositionObject(visualCopy, holder);
    }

    /// <summary>
    /// Throws the item with calculated power.
    /// </summary>
    private void Throw()
    {
        isChargingThrow = false;
        float power = Mathf.Lerp(throwSettings.minThrowForce, throwSettings.maxThrowForce, throwCharge);

        gameObject.transform.CopyLocalTransform(visualCopy.transform, copyScale: false);
        middleHolder.transform.localScale = middleHolderInitScale;
        // Reactivate the original object and apply force
        DestroyCopy();
        gameObject.SetActive(true);

        _rigidbody ??= gameObject.AddComponent<Rigidbody>();
        _rigidbody.isKinematic = false;
        // Throw in camera forward direction
        _rigidbody.AddForce(Camera.main.transform.forward * power * throwSettings.throwDistance, ForceMode.VelocityChange);

        isHolding = false;
    }

    /// <summary>
    /// Cleans up visual copies on destroy.
    /// </summary>
    private void OnDestroy()
    {
        if (visualCopy != null) Destroy(visualCopy);
        if (placementPreview != null) Destroy(placementPreview);
    }
}
