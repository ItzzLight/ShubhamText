using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

public static class DocumentationGenerator
{
    public static void Generate(
        string csFile,
        string outputHtmlPath,
        string? stylesheetPath = null,
        string? scriptPath = null,
        bool updateExisting = true)
    {
        var doc = DocumentationParser.Parse(csFile);

        if (doc == null)
        {
            //throw new InvalidOperationException($"Failed to parse documentation from '{csFile}'.");
            return;
        }

        // If update is set and HTML exists, merge manual descriptions
        if (updateExisting && File.Exists(outputHtmlPath))
        {
            HtmlDocGenerator.MergeManualDescriptions(doc, outputHtmlPath);
        }

        HtmlDocGenerator.GenerateHtml(
            doc,
            outputHtmlPath,
            scriptPath ?? Data.ResolvedScriptPath,
            Data.IconPath,
            File.ReadAllText(csFile), // For source code section
            Data.AddCode
        );
    }
}